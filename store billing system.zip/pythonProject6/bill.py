#from _typeshed import Self
#from _typeshed import Self
import random,os
import time
from tkinter import messagebox
from tkinter import*
from tkinter.font import BOLD
class bill_app:
    def __init__(self,root):
        self.root=root #initialising root
        self.root.geometry("1350x700+0+0")  #providing height width and postion
        self.root.title("BILLING SOFTWARE")#title bar
        bg_color="grey"#if we want color  to be same every where delare it once



        self.icon_title=PhotoImage(file="images/images/logo1.png")
        title=Label(self.root, text="Store Billing System",image=self.icon_title,compound=LEFT,
                    font=("times new roman", 40, "bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        # ===btn_logout===
        btn_logout = Button(self.root, text="Logout",command=self.logout, font=("times new roman", 15, "bold"),bg="yellow",cursor="hand2").place(x=1300,
                                                                                                               y=10,height=50,width=150)

        #===clock===
        self.lbl_clock = Label(self.root,text="welcome to Store Billing System\t\t Date: DD-MM-YYYY \t\t Time: HH:MM:SS ",font=("times new roman", 15), bg="#4d636d", fg="white")
        self.lbl_clock.place(x=0, y=70, relwidth=1, height=30)
        self.update_date_time()

        ########VARIABLES###################################################
        self.wheat=DoubleVar()
        self.rice=DoubleVar()
        self.rajma=DoubleVar()
        self.sugar=DoubleVar()
        self.maida=DoubleVar()
        self.toordal=DoubleVar()


        #####################COLDDRINKS#########################33333

        self.frooti=DoubleVar()
        self.water=DoubleVar()
        self.limca=DoubleVar()
        self.cola=DoubleVar()
        self.fanta=DoubleVar()
        self.sprite=DoubleVar()




        ####################DAIRY############



        self.milk=DoubleVar()
        self.lassi=DoubleVar()
        self.dahi=DoubleVar()
        self.milkshake=DoubleVar()
        self.chaas=DoubleVar()
        self.ghee=DoubleVar()

        ###############total price and discount


        self.groceryprice=StringVar()
        self.colddrinkprice=StringVar()
        self.ddairyprice=StringVar()
        self.grocerydis=StringVar()
        self.colddrinkdis=StringVar()
        self.dairydis=StringVar()


        #############customer######################3


        self.cname=StringVar()#adding this to entry 
        self.cphone=StringVar()
        x=random.randint(1000,9999)
        self.billno = StringVar()
        self.billno.set(str(x))

        self.searchbill=StringVar()


        #CUSTOMER DETAIL FRAME 


        f1=LabelFrame(self.root,text="CUSTOMER DETAILS",bd=10,relief=GROOVE,font=("times new roman",15,"bold"),fg="gold",bg=bg_color)
        f1.place(x=0,y=100,relwidth=10)#width relative to the main frame
        cname_lbl=Label(f1,text="CUSTOMER NAME",font=("times new roman",15,BOLD),fg="black",bg="gold").grid(row=0,column=0,padx=20,pady=5)
        xname_txt=Entry(f1,textvariable=self.cname,width=15,font="arial 15",bd=7,relief=SUNKEN).grid(row=0,column=1,pady=5,padx=10)




        cphone_lbl=Label(f1,text="PHONE NUMBER",font=("times new roman",15,BOLD),fg="black",bg="gold").grid(row=0,column=2,padx=20,pady=5)
        xphone_txt=Entry(f1,textvariable=self.cphone,width=15,font="arial 15",bd=7,relief=SUNKEN).grid(row=0,column=3,pady=5,padx=10)



        cbill_lbl=Label(f1,text="BILL NO",font=("times new roman",15,BOLD),fg="black",bg="gold").grid(row=0,column=4,padx=20,pady=5)
        xbill_txt=Entry(f1,textvariable=self.billno,width=15,font="arial 15",bd=7,relief=SUNKEN).grid(row=0,column=5,pady=5,padx=20)



        #bill_btn=Button(f1,text="SEARCH",command=self.find_bill,width=8,bd=7,relief=GROOVE,font="arial 12 bold").grid(row=0,column=6,pady=10,padx=10)


        
        
        
        #################################################GROCERY FRAME

        f2=LabelFrame(self.root,text="GROCERY",bd=10,relief=GROOVE,font=("times new roman",15,"bold"),fg="gold",bg=bg_color)
        f2.place(x=5,y=170,width=325,height=380)#width relative to the main frame #addding another label frame into the main window
        WHEAT_lbl=Label(f2,text="WHEAT (kg)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=0,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        WHEAT_txt=Entry(f2,textvariable=self.wheat,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=0,column=1,padx=10,pady=10)


        RICE_lbl=Label(f2,text="RICE (kg)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=1,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        RICE_txt=Entry(f2, textvariable=self.rice,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=1,column=1,padx=10,pady=10)

        SUGAR_lbl=Label(f2,text="SUGAR (kg)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=2,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        SUGAR_txt=Entry(f2, textvariable=self.sugar,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=2,column=1,padx=10,pady=10)

        MAIDA_lbl=Label(f2,text="MAIDA (kg)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=3,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        MAIDA_txt=Entry(f2,textvariable=self.maida,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=3,column=1,padx=10,pady=10)
        
        TOOR_DAL_lbl=Label(f2,text="TOOR DAL (kg)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=4,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        TOOR_DAL_txt=Entry(f2,textvariable=self.toordal,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=4,column=1,padx=10,pady=10)
        
        RAJMA=Label(f2,text="RAJMA (kg)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=5,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        RAJMA_txt=Entry(f2,textvariable=self.rajma,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=5,column=1,padx=10,pady=10)


#########################################COLDDRINKS




        f3=LabelFrame(self.root,text="COLD DRINKS",bd=10,relief=GROOVE,font=("times new roman",15,"bold"),fg="gold",bg=bg_color)
        f3.place(x=335,y=170,width=325,height=380)#width relative to the main frame #addding another label frame into the main window
        frooti_lbl=Label(f3,text="FROOTI (200 ML)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=0,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        frooti_txt=Entry(f3,textvariable=self.frooti,width=7,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=0,column=1,padx=10,pady=10)


        water_lbl=Label(f3,text="WATER (1L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=1,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        water_txt=Entry(f3,textvariable=self.water,width=7,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=1,column=1,padx=10,pady=10)

        limca_lbl=Label(f3,text="LIMCA (1.5L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=2,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        limca_txt=Entry(f3,textvariable=self.limca,width=7,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=2,column=1,padx=10,pady=10)

        sprite_lbl=Label(f3,text="SPRITE (1.5L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=3,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        sprite_txt=Entry(f3,textvariable=self.sprite,width=7,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=3,column=1,padx=10,pady=10)
        
        cola_lbl=Label(f3,text="COLA (1.5L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=4,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        cola_txt=Entry(f3,textvariable=self.cola,width=7,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=4,column=1,padx=10,pady=10)
        
        fanta_lbl=Label(f3,text="FANTA (1.5L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=5,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        fanta_txt=Entry(f3,textvariable=self.fanta,width=7,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=5,column=1,padx=10,pady=10)




        ##################################################DAIRY PRODUCTS



        f4=LabelFrame(self.root,text="DAIRY PRODUCTS",bd=10,relief=GROOVE,font=("times new roman",15,"bold"),fg="gold",bg=bg_color)
        f4.place(x=665,y=170,width=325,height=380)#width relative to the main frame #addding another label frame into the main window

        MILK_lbl=Label(f4,text="MILK (L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=0,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        MILK_txt=Entry(f4,textvariable=self.milk,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=0,column=1,padx=10,pady=10)

        LASSI_lbl=Label(f4,text="LASSI (L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=1,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        LASSI_txt=Entry(f4,textvariable=self.lassi,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=1,column=1,padx=10,pady=10)

        GHEE_lbl=Label(f4,text="GHEE (L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=2,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        GHEE_txt=Entry(f4,textvariable=self.ghee,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=2,column=1,padx=10,pady=10)

        DAHI_lbl=Label(f4,text="DAHI (L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=3,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        DAHI_txt=Entry(f4,textvariable=self.dahi,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=3,column=1,padx=10,pady=10)
        
        MILKSHAKE_lbl=Label(f4,text="MILKSHAKE (L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=4,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        MILKSHAKE_txt=Entry(f4,textvariable=self.milkshake,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=4,column=1,padx=10,pady=10)
        
        chaas_lbl=Label(f4,text="CHAAS (L)",font=("times new roman",16,BOLD),bg=bg_color,fg="Gold").grid(row=5,column=0,padx=10,pady=10,sticky='w')#sticky west is used to show all the label to the left
        chaas_txt=Entry(f4,textvariable=self.chaas,width=8,font=("times new roman",16,BOLD),bd=5,relief=SUNKEN).grid(row=5,column=1,padx=10,pady=10)

##########################################BILLAREA

        f5=Frame(self.root,bd=10,relief=GROOVE)
        f5.place(x=996,y=170,width=300,height=380)#width relative to the main frame
        bill_title=Label(f5,text="BILL AREA",font="arial 15",bd=7,relief=GROOVE).pack(fill=X)
        scroll_y=Scrollbar(f5,orient=VERTICAL)
        self.txtarea=Text(f5,yscrollcommand=scroll_y.set)#called self because we want to fetch data and make some changes
        scroll_y.pack(side=RIGHT,fill=Y)
        scroll_y.config(command=self.txtarea.yview)#configuring scroll bar to work for the y view of the text area
        self.txtarea.pack(fill=BOTH,expand=1)#to make the text area work after the specified length

####################################BUTTONFRAME
        f6=LabelFrame(self.root,text="MENU",bd=10,relief=GROOVE,font=("times new roman",15,"bold"),fg="gold",bg=bg_color)
        f6.place(x=0,y=560,relwidth=1,height=140)#width relative to the main frame 
        M1=Label(f6,text="TOTAL GROCERY PRICE",font=("times new roman",14,BOLD),fg="blue").grid(row=0,column=0,padx=10,pady=1,sticky="w")
        m1_txt=Entry(f6,textvariable=self.groceryprice,width=18,font="arial 10 bold",bd=7,relief=SUNKEN).grid(row=0,column=1,padx=10,pady=1)
        

        M2=Label(f6,text="TOTAL COLD DRINK PRICE",font=("times new roman",14,BOLD),fg="blue").grid(row=1,column=0,padx=10,pady=1,sticky="w")
        m2_txt=Entry(f6,textvariable=self.colddrinkprice,width=18,font="arial 10 bold",bd=7,relief=SUNKEN).grid(row=1,column=1,padx=10,pady=1)
        

        M3=Label(f6,text="TOTAL DAIRY PRICE",font=("times new roman",14,BOLD),fg="blue").grid(row=2,column=0,padx=10,pady=1,sticky="w")
        m3_txt=Entry(f6,textvariable=self.ddairyprice,width=18,font="arial 10 bold",bd=7,relief=SUNKEN).grid(row=2,column=1,padx=10,pady=1)
        


        d1=Label(f6,text="GROCERY DISCOUNT",font=("times new roman",14,BOLD),fg="red").grid(row=0,column=2,padx=10,pady=1,sticky="w")
        d1_txt=Entry(f6,textvariable=self.grocerydis,width=18,font="arial 10 bold",bd=7,relief=SUNKEN).grid(row=0,column=3,padx=10,pady=1)
        

        d2=Label(f6,text="COLD DRINK DISCOUNT",font=("times new roman",14,BOLD),fg="red").grid(row=1,column=2,padx=10,pady=1,sticky="w")
        d2_txt=Entry(f6,textvariable=self.colddrinkdis,width=18,font="arial 10 bold",bd=7,relief=SUNKEN).grid(row=1,column=3,padx=10,pady=1)
        

        d3=Label(f6,text="DAIRY DISCOUNT",font=("times new roman",14,BOLD),fg="RED").grid(row=2,column=2,padx=10,pady=1,sticky="w")
        d3_txt=Entry(f6,textvariable=self.dairydis,width=18,font="arial 10 bold",bd=7,relief=SUNKEN).grid(row=2,column=3,padx=10,pady=1)




        btn_f=Frame(f6,bd=7,relief=GROOVE)
        btn_f.place(x=860,width=400,height=100)
        total_btn=Button(btn_f,command=self.total,text="TOTAL",bg="blue",fg="gold",pady=15,width=10,bd=5).grid(row=0,column=0,padx=5,pady=5)
        gbill_btn=Button(btn_f,text="GENERATE BILL",command=self.bill_area,bg="blue",fg="gold",pady=15,width=11,bd=5).grid(row=0,column=1,padx=5,pady=5)
        clear_btn=Button(btn_f,text="CLEAR",command=self.clear_data,bg="blue",fg="gold",pady=15,width=11,bd=5).grid(row=0,column=2,padx=5,pady=5)
        exit_btn=Button(btn_f,text="EXIT",command=self.Exit_app,bg="blue",fg="gold",pady=15,width=9,bd=5).grid(row=0,column=3,padx=5,pady=5)
        self.welcome_bill()


        #####for functioning of total 
    def total(self):
        self.g_w_p=self.wheat.get()*40
        self.g_r_p =self.rice.get()*50
        self.g_s_p=self.sugar.get()*25
        self.g_ra_p=self.rajma.get()*60
        self.g_m_p=self.maida.get()*50
        self.g_t_p=self.toordal.get()*120

        self.total_grocery_price=float( self.g_w_p+
                                        self.g_r_p+
                                        self.g_s_p+
                                        self.g_ra_p+
                                        self.g_m_p+
                                        self.g_t_p
                                    )
        self.groceryprice.set("Rs "+str(self.total_grocery_price))
        self.g_dis=round((self.total_grocery_price*0.05),2)
        self.grocerydis.set("Rs "+str(self.g_dis))

        self.c_fa_p=self.fanta.get() * 80
        self.c_s_p=self.sprite.get() * 70
        self.c_c_p=self.cola.get() * 70
        self.c_l_p=self.limca.get() * 80
        self.c_fr_p=self.frooti.get() * 10
        self.c_w_p=self.water.get() * 15

        self.total_colddrink_price=float(   self.c_fa_p+
                                            self.c_s_p+
                                            self.c_c_p+
                                            self.c_l_p+
                                            self.c_fr_p+
                                            self.c_w_p
                                        )
        self.colddrinkprice.set("Rs "+str(self.total_colddrink_price))
        self.c_dis=round((self.total_colddrink_price * 0.1),2)
        self.colddrinkdis.set("Rs "+str(self.c_dis))

        self.d_m_p=self.milk.get() * 50
        self.d_c_p=self.chaas.get() * 15
        self.d_ms_p=self.milkshake.get() * 30
        self.d_g_p=self.ghee.get() * 800
        self.d_d_p=self.dahi.get() * 35
        self.d_l_p=self.lassi.get() * 20

        self.total_dairy_price=float(   self.d_m_p+
                                        self.d_c_p+
                                        self.d_ms_p+
                                        self.d_g_p+
                                        self.d_d_p+
                                        self.d_l_p
                                    )
        self.ddairyprice.set("Rs "+str(self.total_dairy_price))
        self.d_dis=round((self.total_dairy_price * 0.05),2)
        self.dairydis.set("Rs "+str(self.d_dis))

        self.Total_Bill=float(  self.total_grocery_price+
                                self.total_colddrink_price+
                                self.total_dairy_price-
                                self.g_dis-
                                self.c_dis-
                                self.d_dis
                            )


    def welcome_bill(self):
            self.txtarea.delete('1.0',END)
            self.txtarea.insert(END,"     Welcome to Modern Retail\n")
            self.txtarea.insert(END,f"\n Bill Number : {self.billno.get()}")
            self.txtarea.insert(END,f"\n Customer Name : {self.cname.get()}")
            self.txtarea.insert(END,f"\n Phone Number : {self.cphone.get()}")
            self.txtarea.insert(END, f"\n================================")
            self.txtarea.insert(END, f"\n Products\t\tQTY\tPrice")
            self.txtarea.insert(END, f"\n================================")

    def bill_area(self):
        if self.cname.get()=="" or self.cphone.get()=="":
            messagebox.showerror("error","Customer Details must")
        elif self.groceryprice.get()=="Rs 0.0" and self.colddrinkprice.get()=="Rs 0.0" and self.ddairyprice.get()=="Rs 0.0":
            messagebox.showerror("error","no products purchased")
        else:
            self.welcome_bill()
        # =======Grocery=====
        if self.wheat.get()!=0:
            self.txtarea.insert(END, f"\nWheat\t\t{self.wheat.get()}\t{self.g_w_p}")

        if self.rice.get()!=0:
            self.txtarea.insert(END, f"\nRice\t\t{self.rice.get()}\t{self.g_r_p}")

        if self.sugar.get()!=0:
            self.txtarea.insert(END, f"\nSugar\t\t{self.sugar.get()}\t{self.g_s_p}")

        if self.maida.get()!=0:
            self.txtarea.insert(END, f"\nMaida\t\t{self.maida.get()}\t{self.g_m_p}")

        if self.toordal.get()!=0:
            self.txtarea.insert(END, f"\nToorDal\t\t{self.toordal.get()}\t{self.g_t_p}")

        if self.rajma.get()!=0:
            self.txtarea.insert(END, f"\nRajma\t\t{self.rajma.get()}\t{self.g_ra_p}")

            #=======colddrinks=====

        if self.water.get()!=0:
            self.txtarea.insert(END, f"\nWater\t\t{self.water.get()}\t{self.c_w_p}")

        if self.fanta.get()!=0:
            self.txtarea.insert(END, f"\nFanta\t\t{self.fanta.get()}\t{self.c_fa_p}")

        if self.frooti.get()!=0:
            self.txtarea.insert(END, f"\nFrooti\t\t{self.frooti.get()}\t{self.c_fr_p}")

        if self.limca.get()!=0:
            self.txtarea.insert(END, f"\nLimca\t\t{self.limca.get()}\t{self.c_l_p}")

        if self.sprite.get()!=0:
            self.txtarea.insert(END, f"\nSprite\t\t{self.sprite.get()}\t{self.c_s_p}")

        if self.cola.get()!=0:
            self.txtarea.insert(END, f"\nCola\t\t{self.cola.get()}\t{self.c_c_p}")

            # =======Dairy=====

        if self.milk.get()!=0:
            self.txtarea.insert(END, f"\nMilk\t\t{self.milk.get()}\t{self.d_m_p}")

        if self.chaas.get()!=0:
            self.txtarea.insert(END, f"\nChaas\t\t{self.chaas.get()}\t{self.d_c_p}")

        if self.milkshake.get()!=0:
            self.txtarea.insert(END, f"\nMilkshake\t\t{self.milkshake.get()}\t{self.d_ms_p}")

        if self.ghee.get()!=0:
            self.txtarea.insert(END, f"\nGhee\t\t{self.ghee.get()}\t{self.d_g_p}")

        if self.dahi.get()!=0:
            self.txtarea.insert(END, f"\nDahi\t\t{self.dahi.get()}\t{self.d_d_p}")

        if self.lassi.get()!=0:
            self.txtarea.insert(END, f"\nLassi\t\t{self.lassi.get()}\t{self.d_l_p}")

            self.txtarea.insert(END, f"\n-------------------------------")
        if self.grocerydis.get()!="Rs 0.0":
            self.txtarea.insert(END, f"\n Grocery Discount\t\t\t{self.grocerydis.get()}")
        if self.colddrinkdis.get()!="Rs 0.0":
            self.txtarea.insert(END, f"\n Cold Drinks Discount\t\t\t{self.colddrinkdis.get()}")
        if self.dairydis.get()!="Rs 0.0":
            self.txtarea.insert(END, f"\n Dairy Discount\t\t\t{self.dairydis.get()}")
        self.txtarea.insert(END, f"\n--------------------------------")
        self.txtarea.insert(END, f"\n Total Bill\t\t\t{str(self.Total_Bill)}")
        self.txtarea.insert(END, f"\n--------------------------------")
        self.save_bill()

    def save_bill(self):
        op=messagebox.askyesno("Save Bill","Do you want to save Bill ?")
        if op>0:
            self.bill_data = self.txtarea.get('1.0',END)
            f1=open("BILLS/"+str(self.billno.get())+".txt","w")
            f1.write(self.bill_data)
            f1.close()
            messagebox.showinfo("Saved",f"Bill no :{self.billno.get()} saved Succesfully")
        else:
            return
    




    def find_bill(self):
        present ="no"
        for i in os.listdir("BILLS/"):
            if i.split('.')[0]==self.searchbill.get():
                f1=open(f"BILLS/{i}","r")
                self.txtarea.delete('1.0',END)
                for d in f1:
                    self.txtarea.insert(END,d)
                f1.close()
                present="yes"
            if present=="no":
                messagebox.showerror("Error","INVALID BILL NUMBER")


    


    def clear_data(self):

        op = messagebox.askyesno("Clear", "Do you want to clear Data ?")
        if op > 0:

            self.wheat.set(0)
            self.rice.set(0)
            self.rajma.set(0)
            self.sugar.set(0)
            self.maida.set(0)
            self.toordal.set(0)


        #####################COLDDRINKS#########################33333

            self.frooti.set(0)
            self.water.set(0)
            self.limca.set(0)
            self.cola.set(0)
            self.fanta.set(0)
            self.sprite.set(0)




        ####################DAIRY############



            self.milk.set(0)
            self.lassi.set(0)
            self.dahi.set(0)
            self.milkshake.set(0)
            self.chaas.set(0)
            self.ghee.set(0)

        ###############total price and discount


            self.groceryprice.set("")
            self.colddrinkprice.set("")
            self.ddairyprice.set("")
            self.grocerydis.set("")
            self.colddrinkdis.set("")
            self.dairydis.set("")


        #############customer######################3


            self.cname.set("")    #adding this to entry
            self.cphone.set("")

            self.billno.set("")
            x=random.randint(1000,9999)
            self.billno.set(str(x))

            self.searchbill.set("")
            self.welcome_bill()

    def Exit_app(self):
        op=messagebox.askyesno("Exit","Do you want to exit ?")
        if op>0:
            self.root.destroy()

    def logout(self):
        self.root.destroy()
        os.system("python login.py")

    def update_date_time(self):
        time_=time.strftime("%I:%M:%S")
        date_=time.strftime("%d:%m-%Y")

        self.lbl_clock.config(text=f"welcome to Store Billing System\t\t Date: {str(date_)} \t\t Time: {str(time_)}")
        self.lbl_clock.after(200,self.update_date_time)







root=Tk()#making tkinter object
obj=bill_app(root)#passing the object into the class
root.mainloop()#calling the function

