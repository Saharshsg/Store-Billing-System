import sqlite3
def created_db():
    con=sqlite3.connect(database=r'ims.db')                 #r ka matlab hai r path hai r string use kiya hai
    cur=con.cursor()                            #koi bhi query agar sqlite3 ke le hai to cursor ko establish karna padenga
    cur.execute("CREATE TABLE IF NOT EXISTS employee(eid INTEGER PRIMARY KEY AUTOINCREMENT,name text,email text,gender text,contact text,dob text,doj text,password text,utype text,address text,salary text)")                                                      #jo diffrent queires ko execute karne mai help karta hai
    con.commit()


created_db()